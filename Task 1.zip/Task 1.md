# Task 1 
- Create a bar chart or histogram to visualize the distribution of a 
- categorical or continuous variable, such as the distribution of 
- ages or genders in a population.

# Importing Libraries


```python
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings("ignore")
```


```python
#reading the DataFrame
car=pd.read_csv('cars.csv')
car
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>width</th>
      <th>height</th>
      <th>engine-type</th>
      <th>engine-size</th>
      <th>horsepower</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>dohc</td>
      <td>130</td>
      <td>111</td>
      <td>21</td>
      <td>27</td>
      <td>13495</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>dohc</td>
      <td>130</td>
      <td>111</td>
      <td>21</td>
      <td>27</td>
      <td>16500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>65.5</td>
      <td>52.4</td>
      <td>ohcv</td>
      <td>152</td>
      <td>154</td>
      <td>19</td>
      <td>26</td>
      <td>16500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164</td>
      <td>audi</td>
      <td>gas</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>66.2</td>
      <td>54.3</td>
      <td>ohc</td>
      <td>109</td>
      <td>102</td>
      <td>24</td>
      <td>30</td>
      <td>13950</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164</td>
      <td>audi</td>
      <td>gas</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>66.4</td>
      <td>54.3</td>
      <td>ohc</td>
      <td>136</td>
      <td>115</td>
      <td>18</td>
      <td>22</td>
      <td>17450</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>-1</td>
      <td>95</td>
      <td>volvo</td>
      <td>gas</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>ohc</td>
      <td>141</td>
      <td>114</td>
      <td>23</td>
      <td>28</td>
      <td>16845</td>
    </tr>
    <tr>
      <th>201</th>
      <td>-1</td>
      <td>95</td>
      <td>volvo</td>
      <td>gas</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>68.8</td>
      <td>55.5</td>
      <td>ohc</td>
      <td>141</td>
      <td>160</td>
      <td>19</td>
      <td>25</td>
      <td>19045</td>
    </tr>
    <tr>
      <th>202</th>
      <td>-1</td>
      <td>95</td>
      <td>volvo</td>
      <td>gas</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>ohcv</td>
      <td>173</td>
      <td>134</td>
      <td>18</td>
      <td>23</td>
      <td>21485</td>
    </tr>
    <tr>
      <th>203</th>
      <td>-1</td>
      <td>95</td>
      <td>volvo</td>
      <td>diesel</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>ohc</td>
      <td>145</td>
      <td>106</td>
      <td>26</td>
      <td>27</td>
      <td>22470</td>
    </tr>
    <tr>
      <th>204</th>
      <td>-1</td>
      <td>95</td>
      <td>volvo</td>
      <td>gas</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>ohc</td>
      <td>141</td>
      <td>114</td>
      <td>19</td>
      <td>25</td>
      <td>22625</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 15 columns</p>
</div>




```python
car.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 205 entries, 0 to 204
    Data columns (total 15 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   symboling          205 non-null    int64  
     1   normalized-losses  205 non-null    object 
     2   make               205 non-null    object 
     3   fuel-type          205 non-null    object 
     4   body-style         205 non-null    object 
     5   drive-wheels       205 non-null    object 
     6   engine-location    205 non-null    object 
     7   width              205 non-null    float64
     8   height             205 non-null    float64
     9   engine-type        205 non-null    object 
     10  engine-size        205 non-null    int64  
     11  horsepower         205 non-null    object 
     12  city-mpg           205 non-null    int64  
     13  highway-mpg        205 non-null    int64  
     14  price              205 non-null    int64  
    dtypes: float64(2), int64(5), object(8)
    memory usage: 24.2+ KB
    

# visualization


```python
car.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>width</th>
      <th>height</th>
      <th>engine-type</th>
      <th>engine-size</th>
      <th>horsepower</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>dohc</td>
      <td>130</td>
      <td>111</td>
      <td>21</td>
      <td>27</td>
      <td>13495</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>dohc</td>
      <td>130</td>
      <td>111</td>
      <td>21</td>
      <td>27</td>
      <td>16500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>?</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>65.5</td>
      <td>52.4</td>
      <td>ohcv</td>
      <td>152</td>
      <td>154</td>
      <td>19</td>
      <td>26</td>
      <td>16500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164</td>
      <td>audi</td>
      <td>gas</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>66.2</td>
      <td>54.3</td>
      <td>ohc</td>
      <td>109</td>
      <td>102</td>
      <td>24</td>
      <td>30</td>
      <td>13950</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164</td>
      <td>audi</td>
      <td>gas</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>66.4</td>
      <td>54.3</td>
      <td>ohc</td>
      <td>136</td>
      <td>115</td>
      <td>18</td>
      <td>22</td>
      <td>17450</td>
    </tr>
  </tbody>
</table>
</div>




```python
# checking the relationship between width and price of cars
plt.figure(figsize=(10,10))
x=car['width'] # independent variable
y=car['price'] # dependent vari
plt.scatter(x,y)
plt.xlabel("Width of car")
plt.ylabel("Price of car")
plt.title("Width v/s Price of car")
plt.show()
```


    
![png](output_7_0.png)
    



```python
# ploting histogram in categorical ani numerical data
# fuel-type coli=umn
plt.hist(car['fuel-type'])
plt.xlabel('Fuel-type')
plt.ylabel('No of cars')
plt.title('price v/s no of cars')
c=car['fuel-type'].value_counts()
plt.yticks(c)
plt.show()
```


    
![png](output_8_0.png)
    



```python
# Barplot()
car['fuel-type'].value_counts().plot(kind='bar')
plt.show()
```


    
![png](output_9_0.png)
    



```python

```
